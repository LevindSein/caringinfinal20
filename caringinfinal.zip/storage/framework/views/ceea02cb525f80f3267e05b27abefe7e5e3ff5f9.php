<?php if($message = Session::get('pass')): ?>
<div class="alert alert-success alert-block" id="pass-alert">
        <strong>Success! </strong><?php echo e($message); ?>

</div>
<?php endif; ?>

<script>
    $(document).ready(function () {
        $("#pass-alert")
            .fadeTo(8000, 7000)
            .slideUp(7000, function () {
                $("#pass-alert").slideUp(7000);
            });
    });
</script><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/message/password-message.blade.php ENDPATH**/ ?>