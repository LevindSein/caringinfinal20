<?php    
    echo "<script>alert('sisa under construction')</script>";
?><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/kasir/sisa.blade.php ENDPATH**/ ?>