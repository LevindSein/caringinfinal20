
<?php $__env->startSection('title'); ?>
<h3 class="h3 mb-4 text-primary"><b><?php echo e($dataset->kd_kontrol); ?></b></h3>
<title>Tambah Tagihan Air Bersih | BP3C</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<form class="user" action="<?php echo e(url('tagihan/airbersih')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group col-lg-12">
        <label for="nama">Pengguna</label>
        <input
            required
            value="<?php echo e($dataset->nama); ?>"
            name="nama"
            class="form-control"
            id="nama">
    </div>
    <div class="form-group col-lg-12">
        <label for="lokasi">No.Los</label>
        <input
            readonly
            value="<?php echo e($ket->no_alamat); ?>"
            name="lokasi"
            class="form-control"
            id="lokasi">
    </div>
    <?php if($ket->lok_tempat != NULL): ?>
    <div class="form-group col-lg-12">
        <label for="ket">Kode Sebelumnya</label>
        <input
            readonly
            value="<?php echo e($ket->lok_tempat); ?>"
            name="ket"
            class="form-control"
            id="ket">
    </div>
    <?php endif; ?>
    <div class="form-group col-lg-12">
        <label for="awal">Stand Awal Air Bersih <span style="color:red;">*</span></label>
        <input
            required
            value="<?php echo e(number_format($dataset->awal_airbersih)); ?>"
            autocomplete="off"
            type="text" 
            pattern="^[\d,]+$"
            name="awal"
            class="form-control"
            id="awal">
    </div>
    <div class="form-group col-lg-12">
        <label for="akhir">Stand Akhir Air Bersih <span style="color:red;">*</span></label>
        <input
            autofocus
            required
            value="<?php echo e(number_format($suggest)); ?>"
            autocomplete="off"
            type="text" 
            pattern="^[\d,]+$"
            name="akhir"
            class="form-control"
            id="akhir">
    </div>
    <div class="form-group col-lg-12">
        <label for="laporan">Laporan (optional)</label>
        <textarea
            autocomplete="off"
            type="text" 
            name="laporan"
            class="form-control"
            id="laporan">
        </textarea>
    </div>
    <input type="hidden" name="hidden_id" id="hidden_id" value="<?php echo e($dataset->id); ?>">
    <input type="hidden" name="kd_kontrol" id="kd_kontrol" value="<?php echo e($dataset->kd_kontrol); ?>">
    <div class="form-group col-lg-12">
        <Input type="submit" id="tambah" value="Tambah Tagihan" class="btn btn-primary btn-user btn-block">
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsplus'); ?>
<script src="<?php echo e(asset('js/form-airbersih.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tagihan.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/tagihan/airbersih.blade.php ENDPATH**/ ?>