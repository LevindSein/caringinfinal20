<?php    
    echo "<script>alert('settings under construction')</script>";
?><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/kasir/settings.blade.php ENDPATH**/ ?>