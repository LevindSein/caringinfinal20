<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Penerimaan Kasir</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/penerimaan.css')); ?>" media="all"/>
        <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>">
    </head>

    <body onload="window.print()">
        <div>
            <header class="clearfix">
                <h2 style="text-align:center;">Rekap Penerimaan</h2>
                <div id="project">
                    <div>
                        <span>Nama Kasir</span>:
                        <?php echo e(Session::get('username')); ?></div>
                    <div>
                        <span>Tanggal Bayar</span>:
                        <?php echo e($tanggal); ?></div>
                </div>
            </header>
            <main>
                <table class="tg">
                    <thead>
                        <tr>
                            <th class="tg-r8fv" rowspan="3">Blok</th>
                            <th class="tg-r8fv" rowspan="3">Rek</th>
                            <th class="tg-r8fv" colspan="8">Penerimaan Tunai</th>
                            <th class="tg-r8fv" rowspan="3">Jumlah</th>
                            <th class="tg-r8fv" rowspan="3">Disc</th>
                        </tr>
                        <tr>
                            <th class="tg-r8fv" rowspan="2">Listrik</th>
                            <th class="tg-r8fv" rowspan="2">Air Brs</th>
                            <th class="tg-ccvv" rowspan="2" style="vertical-align:middle;">K.aman</th>
                            <th class="tg-ccvv" rowspan="2" style="vertical-align:middle;">K.bersih</th>
                            <th class="tg-r8fv" colspan="2">Denda</th>
                            <th class="tg-r8fv" rowspan="2">Air Ktr</th>
                            <th class="tg-r8fv" rowspan="2">Lain<sup>2</sup></th>
                        </tr>
                        <tr>
                            <th class="tg-ccvv">Listrik</th>
                            <th class="tg-ccvv">Air Brs</th>
                        </tr>
                        <tr>
                            <th class="tg-g255" colspan="12" style="height:1px"></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="tg-r8fz"><b><?php echo e($d['blok']); ?></b></td>
                            <td class="tg-r8fx"><?php echo e($d['rek']); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($d['listrik'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($d['airbersih'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($d['keamananipk'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($d['kebersihan'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($d['denlistrik'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($d['denairbersih'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($d['airkotor'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($d['lain'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($d['jumlah'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($d['diskon'])); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tr>
                        <td class="tg-g255" colspan="12" style="height:1px"></td>
                    </tr>
                    <tr>
                        <td class="tg-r8fz"><b>Total<b></td>
                        <td class="tg-r8fx"><b><?php echo e($t_rekap['rek']); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($t_rekap['listrik'])); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($t_rekap['airbersih'])); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($t_rekap['keamananipk'])); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($t_rekap['kebersihan'])); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($t_rekap['denlistrik'])); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($t_rekap['denairbersih'])); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($t_rekap['airkotor'])); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($t_rekap['lain'])); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($t_rekap['jumlah'])); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($t_rekap['diskon'])); ?></b></td>
                    </tr>
                </table>
            </main>
        </div>
        <div style="page-break-before:always">
            <header class="clearfix">
                <h2 style="text-align:center;">Rincian Penerimaan</h2>
                <div id="project">
                    <div>
                        <span>Nama Kasir</span>:
                        <?php echo e(Session::get('username')); ?></div>
                    <div>
                        <span>Tanggal Bayar</span>:
                        <?php echo e($tanggal); ?></div>
                </div>
            </header>
            <main>
                <table class="tg">
                    <thead>
                        <tr>
                            <th class="tg-r8fv" rowspan="3">No</th>
                            <th class="tg-r8fv" rowspan="3">Rek</th>
                            <th class="tg-r8fv" rowspan="3">Kontrol</th>
                            <th class="tg-r8fv" rowspan="3">Nama</th>
                            <th class="tg-r8fv" colspan="8">Penerimaan Tunai</th>
                            <th class="tg-r8fv" rowspan="3">Jumlah</th>
                            <th class="tg-r8fv" rowspan="3">Disc</th>
                        </tr>
                        <tr>
                            <th class="tg-r8fv" rowspan="2">Listrik</th>
                            <th class="tg-r8fv" rowspan="2">Air Brs</th>
                            <th class="tg-ccvv" rowspan="2" style="vertical-align:middle;">K.aman</th>
                            <th class="tg-ccvv" rowspan="2" style="vertical-align:middle;">K.bersih</th>
                            <th class="tg-r8fv" colspan="2">Denda</th>
                            <th class="tg-r8fv" rowspan="2">Air Ktr</th>
                            <th class="tg-r8fv" rowspan="2">Lain<sup>2</sup></th>
                        </tr>
                        <tr>
                            <th class="tg-ccvv">Listrik</th>
                            <th class="tg-ccvv">Air Brs</th>
                        </tr>
                        <tr>
                            <th class="tg-g255" colspan="13" style="height:1px"></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $listrik = 0;
                    $denlistrik = 0;
                    $airbersih = 0;
                    $denairbersih = 0;
                    $keamananipk = 0;
                    $kebersihan = 0;
                    $airkotor = 0;
                    $lain = 0;
                    $jumlah = 0;
                    $diskon = 0;
                    $i = 1;
                    ?>
                    <?php $__currentLoopData = $rincian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="tg-r8fz"><?php echo e($i); ?></td>
                            <td class="tg-r8fz"><?php echo e($r['rek']); ?></td>
                            <td class="tg-r8fz"><?php echo e($r['kode']); ?></td>
                            <td class="tg-r8fy"><?php echo e(substr($r['pengguna'],0,13)); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($r['listrik'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($r['airbersih'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($r['keamananipk'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($r['kebersihan'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($r['denlistrik'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($r['denairbersih'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($r['airkotor'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($r['lain'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($r['jumlah'])); ?></td>
                            <td class="tg-r8fx"><?php echo e(number_format($r['diskon'])); ?></td>
                        </tr>
                        <?php 
                        $listrik = $listrik + $r['listrik'];
                        $denlistrik = $denlistrik + $r['denlistrik'];
                        $airbersih = $airbersih + $r['airbersih'];
                        $denairbersih = $denairbersih + $r['denairbersih'];
                        $keamananipk = $keamananipk + $r['keamananipk'];
                        $kebersihan = $kebersihan + $r['kebersihan'];
                        $airkotor = $airkotor + $r['airkotor'];
                        $lain = $lain + $r['lain'];
                        $jumlah = $jumlah + $r['jumlah'];
                        $diskon = $diskon + $r['diskon'];
                        $i++;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tr>
                        <td class="tg-g255" colspan="13" style="height:1px"></td>
                    </tr>
                    <tr>
                        <td class="tg-r8fz" colspan="4"><b>Total<b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($listrik)); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($airbersih)); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($keamananipk)); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($kebersihan)); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($denlistrik)); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($denairbersih)); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($airkotor)); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($lain)); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($jumlah)); ?></b></td>
                        <td class="tg-r8fx"><b><?php echo e(number_format($diskon)); ?></b></td>
                    </tr>
                </table>
                <div id="notices">
                    <div style="text-align:right;">
                        <b>Bandung, <?php echo e($cetak); ?></b>
                    </div>
                    <br><br><br><br><br>
                    <div class="notice" style="text-align:right;"><?php echo e(Session::get('username')); ?></div>
                </div>
            </main>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/kasir/penerimaan.blade.php ENDPATH**/ ?>