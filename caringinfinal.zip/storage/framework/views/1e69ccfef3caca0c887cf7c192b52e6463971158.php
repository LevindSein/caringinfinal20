
<?php $__env->startSection('head'); ?>
<!-- Tambah Content Pada Head -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Tambah Content Pada Body Utama -->
<title>Riwayat Login | BP3C</title>
<div class = "container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Riwayat Login</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table 
                    class="table table-bordered" 
                    id="tabelLog"
                    cellspacing="0"
                    width="100%"
                    style="font-size:0.75rem;">
                    <thead>
                        <tr>
                            <th style="width:10px;">No.</th>
                            <th>Username</th>
                            <th>Nama</th>
                            <th>KTP</th>
                            <th>HP</th>
                            <th>Role</th>
                            <th>Platform</th>
                            <th>Login</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Tambah Content pada Body modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Tambah Content pada Body JS -->
<script src="<?php echo e(asset('js/log.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/log/index.blade.php ENDPATH**/ ?>