<?php    
    echo "<script>alert('prabayar under construction')</script>";
?><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/kasir/prabayar.blade.php ENDPATH**/ ?>