<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Pembayaran <?php echo e($blok); ?></title>
        <link rel="stylesheet" href="<?php echo e(asset('css/pembayaran.css')); ?>" media="all"/>
        <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>">
    </head>
    <body onload="window.print()">
        <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i = 1; ?>
            <div class="row" style="page-break-after:always">
                <table class="tg" style="undefined;table-layout: fixed; width: 450px">
                <colgroup>
                    <col style="width: 30px">
                    <col style="width: 80px">
                    <col style="width: 50px">
                    <col style="width: 80px">
                    <col style="width: 80px">
                </colgroup>
                <thead>
                    <tr>
                        <th class="tg-gmla" colspan="5"><span style="font-weight:bold">BADAN PENGELOLA</span><br><span style="font-weight:bold">PUSAT PERDAGANGAN CARINGIN</span><br><span style="font-weight:bold">SEGI PEMBAYARAN</span></th>
                    </tr>
                    <tr>
                        <td class="tg-0r18" colspan="5"><span style="font-weight:bold"><?php echo e($bulan); ?></span></td>
                    </tr>
                    <tr>
                        <td class="tg-zd5i" colspan="2">Pedagang</td>
                        <td class="tg-tb39" colspan="3">: <?php echo e($d[1]); ?></td>
                    </tr>
                    <tr>
                        <td class="tg-zd5i" colspan="2">Kontrol</td>
                        <td class="tg-tb39" colspan="3">: <?php echo e($d[0]); ?></td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="tg-umgj" colspan="4">FASILITAS</td>
                        <td class="tg-95y4">HARGA</td>
                    </tr>
                    <?php if($d[2] != 0): ?>
                    <tr>
                        <td class="tg-0r15"><?php echo e($i); ?>.</td>
                        <td class="tg-tb31" colspan="3">Listrik</td>
                        <td class="tg-7jiy"><?php echo e(number_format($d[2])); ?></td>
                    </tr>
                    <tr>
                        <td class="tg-0r15"></td>
                        <td class="tg-tb31"></td>
                        <td class="tg-tb31">Daya</td>
                        <td class="tg-7jip"><?php echo e(number_format($d['daya_listrik'])); ?></td>
                        <td class="tg-7jiy"></td>
                    </tr>
                    <tr>
                        <td class="tg-0r15"></td>
                        <td class="tg-tb31"></td>
                        <td class="tg-tb31">Awal</td>
                        <td class="tg-7jip"><?php echo e(number_format($d['awal_listrik'])); ?></td>
                        <td class="tg-7jiy"></td>
                    </tr>
                    <tr>
                        <td class="tg-0r15"></td>
                        <td class="tg-tb31"></td>
                        <td class="tg-tb31">Akhir</td>
                        <td class="tg-7jip"><?php echo e(number_format($d['akhir_listrik'])); ?></td>
                        <td class="tg-7jiy"></td>
                    </tr>
                    <tr>
                        <td class="tg-0r15"></td>
                        <td class="tg-tb31"></td>
                        <td class="tg-tb31">Pakai</td>
                        <td class="tg-7jip"><?php echo e(number_format($d['daya_listrik'])); ?></td>
                        <td class="tg-7jiy"></td>
                    </tr>
                    <?php $i++; ?>
                    <?php endif; ?>
                    <?php if($d[3] != 0): ?>
                    <tr>
                        <td class="tg-0r15"><?php echo e($i); ?>.</td>
                        <td class="tg-tb31" colspan="3">Air Bersih</td>
                        <td class="tg-7jiy"><?php echo e(number_format($d[3])); ?></td>
                    </tr>
                    <tr>
                        <td class="tg-0r15"></td>
                        <td class="tg-tb31"></td>
                        <td class="tg-tb31">Awal</td>
                        <td class="tg-7jip"><?php echo e(number_format($d['awal_airbersih'])); ?></td>
                        <td class="tg-7jiy"></td>
                    </tr>
                    <tr>
                        <td class="tg-0r15"></td>
                        <td class="tg-tb31"></td>
                        <td class="tg-tb31">Akhir</td>
                        <td class="tg-7jip"><?php echo e(number_format($d['akhir_airbersih'])); ?></td>
                        <td class="tg-7jiy"></td>
                    </tr>
                    <tr>
                        <td class="tg-0r15"></td>
                        <td class="tg-tb31"></td>
                        <td class="tg-tb31">Pakai</td>
                        <td class="tg-7jip"><?php echo e(number_format($d['pakai_airbersih'])); ?></td>
                        <td class="tg-7jiy"></td>
                    </tr>
                    <?php $i++; ?>
                    <?php endif; ?>
                    <?php if($d[4] != 0): ?>
                    <tr>
                        <td class="tg-0r15"><?php echo e($i); ?>.</td>
                        <td class="tg-tb31" colspan="3">Keamanan IPK</td>
                        <td class="tg-7jiy"><?php echo e(number_format($d[4])); ?></td>
                    </tr>
                    <?php $i++; ?>
                    <?php endif; ?>
                    <?php if($d[5] != 0): ?>
                    <tr>
                        <td class="tg-0r15"><?php echo e($i); ?>.</td>
                        <td class="tg-tb31" colspan="3">Kebersihan</td>
                        <td class="tg-7jiy"><?php echo e(number_format($d[5])); ?></td>
                    </tr>
                    <?php $i++; ?>
                    <?php endif; ?>
                    <?php if($d[6] != 0): ?>
                    <tr>
                        <td class="tg-0r15"><?php echo e($i); ?>.</td>
                        <td class="tg-tb31" colspan="3">Air Kotor</td>
                        <td class="tg-7jiy"><?php echo e(number_format($d[6])); ?></td>
                    </tr>
                    <?php $i++; ?>
                    <?php endif; ?>
                    <?php if($d[7] != 0): ?>
                    <tr>
                        <td class="tg-0r15"><?php echo e($i); ?>.</td>
                        <td class="tg-tb31" colspan="3">Tunggakan</td>
                        <td class="tg-7jiy"><?php echo e(number_format($d[7])); ?></td>
                    </tr>
                    <?php $i++; ?>
                    <?php endif; ?>
                    <?php if($d[8] != 0): ?>
                    <tr>
                        <td class="tg-0r15"><?php echo e($i); ?>.</td>
                        <td class="tg-tb31" colspan="3">Denda</td>
                        <td class="tg-7jiy"><?php echo e(number_format($d[8])); ?></td>
                    </tr>
                    <?php $i++; ?>
                    <?php endif; ?>
                    <?php if($d[9] != 0): ?>
                    <tr>
                        <td class="tg-0r15"><?php echo e($i); ?>.</td>
                        <td class="tg-tb31" colspan="3">Lain - Lain</td>
                        <td class="tg-7jiy"><?php echo e(number_format($d[9])); ?></td>
                    </tr>
                    <?php $i++; ?>
                    <?php endif; ?>
                    <?php if($d[2] == 0): ?>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31" colspan="3">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-7jip">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-7jip">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-7jip">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-7jip">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <?php endif; ?>
                    <?php if($d[3] == 0): ?>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31" colspan="3">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-7jip">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-7jip">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-tb31">&nbsp;</td>
                        <td class="tg-7jip">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <?php endif; ?>
                    <?php if($d[4] == 0): ?>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31" colspan="3">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <?php endif; ?>
                    <?php if($d[5] == 0): ?>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31" colspan="3">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <?php endif; ?>
                    <?php if($d[6] == 0): ?>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31" colspan="3">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <?php endif; ?>
                    <?php if($d[7] == 0): ?>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31" colspan="3">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <?php endif; ?>
                    <?php if($d[8] == 0): ?>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31" colspan="3">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <?php endif; ?>
                    <?php if($d[9] == 0): ?>
                    <tr>
                        <td class="tg-0r15">&nbsp;</td>
                        <td class="tg-tb31" colspan="3">&nbsp;</td>
                        <td class="tg-7jiy">&nbsp;</td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <td class="tg-ey1n" colspan="3">TOTAL</td>
                        <td class="tg-7jit"><span style="font-weight:bold">Rp.</span></td>
                        <td class="tg-q23v"><?php echo e(number_format($d['total'])); ?></td>
                    </tr>
                    <tr>
                        <td class="tg-0r89" colspan="5"><br>No.Faktur : <?php echo e($d['faktur']); ?></td>
                    </tr>
                    <tr>
                        <td class="tg-0r89" colspan="5">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="tg-zd55" colspan="5">Segi pembayaran ini adalah bukti transaksi yang sah.<br>Harap disimpan<br>&nbsp;</td>
                    </tr>
                </tbody>
                </table>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/tagihan/pembayaran.blade.php ENDPATH**/ ?>