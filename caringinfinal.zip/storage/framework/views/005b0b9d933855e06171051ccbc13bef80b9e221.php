
<?php $__env->startSection('head'); ?>
<!-- Tambah Content Pada Head -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Tambah Content Pada Body Utama -->
<div class = "container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <title>Surat Listrik | BP3C</title>
            <h6 class="m-0 font-weight-bold text-primary">Data Surat Pengajuan Listrik Bulan <?php echo e($bulan); ?></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive ">
                <table
                    class="table"
                    id="tabelTempat"
                    width="100%"
                    cellspacing="0"
                    style="font-size:0.75rem;">
                    <thead class="table-bordered">
                        <tr>
                            <th>Kontrol</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align:center"><?php echo e($d->kd_kontrol); ?></td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Tambah Content pada Body JS -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/tempatusaha/surat-listrik.blade.php ENDPATH**/ ?>