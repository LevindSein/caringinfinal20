<?php    
    echo "<script>alert('selesai under construction')</script>";
?><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/kasir/selesai.blade.php ENDPATH**/ ?>