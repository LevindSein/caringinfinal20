<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Pemakaian Kebersihan | BP3C</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/style-pemakaian1.css')); ?>" media="all"/>
        <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>">
    </head>
    <body onload="window.print()">  
        <?php for($i=1;$i<=2;$i++): ?>
        <?php if($i == 1): ?>
        <h2 style="text-align:center;">REKAP PEMAKAIAN KEBERSIHAN<br><?php echo e($bln); ?></h2>
        <main>
            <table class="tg">
                <tr>
                    <th class="tg-r8fv">No.</th>
                    <th class="tg-r8fv">Blok</th>
                    <th class="tg-r8fv">Jumlah Los</th>
                    <th class="tg-r8fv">Subtotal</th>
                    <th class="tg-r8fv">Diskon</th>
                    <th class="tg-r8fv">Tagihan</th>
                    <th class="tg-r8fv">Realisasi</th>
                    <th class="tg-r8fv">Selisih</th>
                </tr>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="tg-cegc"><?php echo e($no); ?></td>
                    <td class="tg-cegc"><?php echo e($d->blok); ?></td>
                    <td class="tg-cegc"><?php echo e($d->pengguna); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->subtotal)); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->diskon)); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->tagihan)); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->realisasi)); ?></td>
                    <td class="tg-g25h"><?php echo e(number_format($d->selisih)); ?></td>
                </tr>
                <?php $no++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="tg-vbo4" style="text-align:center;" colspan="2">Total</td>
                    <td class="tg-vbo4" style="text-align:center;"><?php echo e(number_format($ttlRekap[0])); ?></td>
                    <td class="tg-8m6k"><?php echo e(number_format($ttlRekap[1])); ?></td>
                    <td class="tg-8m6k">Rp. <?php echo e(number_format($ttlRekap[2])); ?></td>
                    <td class="tg-8m6k">Rp. <?php echo e(number_format($ttlRekap[3])); ?></td>
                    <td class="tg-8m6k">Rp. <?php echo e(number_format($ttlRekap[4])); ?></td>
                    <td class="tg-8m6k">Rp. <?php echo e(number_format($ttlRekap[5])); ?></td>
                </tr>
            </table>
        </main>
        <?php else: ?>
        <h2 style="text-align:center;page-break-before:always">RINCIAN PEMAKAIAN KEBERSIHAN<br><?php echo e($bln); ?></h2>
        <?php $__currentLoopData = $rincian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <br>
            <h3><?php echo e($data[0]); ?></h3>
            <main>
                <table class="tg">
                    <tr>
                        <th class="tg-r8fv">No.</th>
                        <th class="tg-r8fv">Kontrol</th>
                        <th class="tg-r8fv">Pengguna</th>
                        <th class="tg-r8fv">Jml Los</th>
                        <th class="tg-r8fv">Subtotal</th>
                        <th class="tg-r8fv">Diskon</th>
                        <th class="tg-r8fv">Tagihan</th>
                        <th class="tg-r8fv">Realisasi</th>
                        <th class="tg-r8fv">Selisih</th>
                    </tr>
                    <?php $no = 1; ?>
                    <?php $__currentLoopData = $data[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="tg-cegc"><?php echo e($no); ?></td>
                        <td class="tg-cegc"><?php echo e($d->kontrol); ?></td>
                        <td class="tg-cegc" style="text-align:left;white-space: normal;"><?php echo e($d->pengguna); ?></td>
                        <td class="tg-cegc"><?php echo e(number_format($d->jumlah)); ?></td>
                        <td class="tg-cegc"><?php echo e(number_format($d->subtotal)); ?></td>
                        <td class="tg-cegc"><?php echo e(number_format($d->diskon)); ?></td>
                        <td class="tg-cegc"><?php echo e(number_format($d->tagihan)); ?></td>
                        <td class="tg-cegc"><?php echo e(number_format($d->realisasi)); ?></td>
                        <td class="tg-cegc"><?php echo e(number_format($d->selisih)); ?></td>
                    </tr>
                    <?php $no++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $data[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="tg-vbo4" style="text-align:center;" colspan="3">Total</td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->jumlah)); ?></td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->subtotal)); ?></td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->diskon)); ?></td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->tagihan)); ?></td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->realisasi)); ?></td>
                        <td class="tg-8m6k"><?php echo e(number_format($d->selisih)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </main>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php endfor; ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/pemakaian/kebersihan.blade.php ENDPATH**/ ?>