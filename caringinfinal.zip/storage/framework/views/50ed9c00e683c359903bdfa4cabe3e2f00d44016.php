<div class="table-responsive ">
    <table
        class="table"
        id="harian"
        width="100%"
        cellspacing="0"
        style="font-size:0.75rem;">
        <thead class="table-bordered">
            <tr>
                <th rowspan="2" style="background-color:rgba(203, 203, 203, 0.2);">Tgl Bayar</th>
                <th rowspan="2" style="background-color:rgba(203, 203, 203, 0.2);">Kontrol</th>
                <th rowspan="2" style="background-color:rgba(203, 203, 203, 0.2);">Pengguna</th>
                <th colspan="6">Bayar</th>
                <th rowspan="2">Tagihan</th>
                <th rowspan="2">Realisasi</th>
                <th rowspan="2">Selisih</th>
                <th rowspan="2" style="background-color:rgba(203, 203, 203, 0.2);">Via Bayar</th>
                <th rowspan="2" style="background-color:rgba(203, 203, 203, 0.2);">Penerima</th>
            </tr>
            <tr>
                <th>Listrik</th>
                <th>Air Bersih</th>
                <th>Keamanan IPK</th>
                <th>Kebersihan</th>
                <th>Air Kotor</th>
                <th>Lain Lain</th>
            </tr>
        </thead>
    </table>
</div><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/pendapatan/harian.blade.php ENDPATH**/ ?>