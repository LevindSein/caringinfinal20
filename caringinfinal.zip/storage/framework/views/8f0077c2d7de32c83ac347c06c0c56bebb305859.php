<?php
    echo "<script>window.close();</script>";
?><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/tempatusaha/handle.blade.php ENDPATH**/ ?>