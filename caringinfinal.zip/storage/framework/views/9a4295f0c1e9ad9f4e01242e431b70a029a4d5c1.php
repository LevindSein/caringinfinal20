
<?php $__env->startSection('head'); ?>
<!-- Tambah Content Pada Head -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Tambah Content Pada Body Utama -->
<title>Details Tagihan Tempat Usaha | BP3C</title>
<div class = "container-fluid">
    <div class="d-sm-flex align-items-center justify-content-center">
        <h3 class="h3 mb-4 text-primary"><b><?php echo e($blok); ?></b></h3>
    </div>
    <div class="mb-4">
        <div class="card-body">
            <div class="row justify-content-center">
                <div class="card shadow col-lg-6">
                    <div class="p-4">
                        <div class="form-group col-lg-12">
                            <div class="d-sm-flex align-items-center justify-content-between">
                                <label>Kode Kontrol</label>
                                <label>Status</label>
                            </div>
                            <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="input-group">
                                <button 
                                    aria-expanded="true" 
                                    aria-controls="exampleAccordion1" 
                                    data-toggle="collapse" 
                                    href="#<?php echo e($d->kd_kontrol); ?>" 
                                    class="form-control shadow"
                                    aria-describedby="inputGroupPrepend"
                                    style="text-align:left;"><?php echo e($d->kd_kontrol); ?>

                                </button>
                                <div class="input-group-prepend">
                                    <?php
                                    if($d->stt_tempat == 1){$status = 'Aktif';}else{$status = 'Pasif';}
                                    ?>
                                    <span class="input-group-text shadow" style="<?php echo e(($status == 'Aktif') ? 'background-color:#1cc88a;color:#ffffff;' : ''); ?>" id="inputGroupPrepend"><?php echo e($status); ?></span>
                                </div>
                            </div>
                            <div id="exampleAccordion" data-children=".item">
                                <div class="item">
                                    <br>
                                    <div 
                                        data-parent="#exampleAccordion" 
                                        id="<?php echo e($d->kd_kontrol); ?>" 
                                        class="collapse">
                                        <p>Pemilik : <?php echo e($d->pemilik); ?></p>
                                        <p>Pengguna : <?php echo e($d->pengguna); ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group col-lg-12">
                                <a href="<?php echo e(url('tempatusaha/rekap')); ?>" type="button" class="btn btn-primary btn-user btn-block">OK</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Tambah Content pada Body modal -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<!-- Tambah Content pada Body JS -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/tempatusaha/details-rekap.blade.php ENDPATH**/ ?>