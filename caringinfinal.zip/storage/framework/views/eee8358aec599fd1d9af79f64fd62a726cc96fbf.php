<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>FORM ALAT METERAN</title>
        <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/style-bulanan.css')); ?>" media="all" />
    </head>
  
    <body onload="window.print()">
        <?php for($i=1;$i<=2;$i++): ?>
        <?php if($i == 1): ?>
        <h2 style="text-align:center;">FORM METERAN LISTRIK</h2><h2 style="text-align:center;"><?php echo e($bulan); ?></h2>
        <?php $__currentLoopData = $dataset[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($data[0]); ?></h3>
        <main>
            <table class="tg">
                <thead>
                    <tr>
                        <th class="tg-r8fv">No.</th>
                        <th class="tg-r8fv">Kontrol</th>
                        <th class="tg-r8fv">Pengguna</th>
                        <th class="tg-r8fv">Nomor</th>
                        <th class="tg-r8fv">Lalu</th>
                        <th class="tg-r8fv" style="width:18%">Baru</th>
                        <th class="tg-r8fv" style="width:10%">Ket.</th>
                    </tr>
                </thead>
                <?php $x=1; ?>
                <?php $__currentLoopData = $data[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <td class="tg-cegc"><?php echo e($x); ?></td>
                        <td class="tg-cegc"><?php echo e($d->kontrol); ?></td>
                        <td class="tg-g25h" style="text-align:left;"><?php echo e(substr($d->nama,0,13)); ?></td>
                        <td class="tg-g25h" style="text-align:center;"><?php echo e(($d->nomor)); ?></td>
                        <td class="tg-g25h" style="text-align:right;"><?php echo e(number_format($d->lalu)); ?></td>
                        <td></td>
                        <td><?php echo e($d->lokasi); ?></td>
                    </tr>
                </tbody>
                <?php $x++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </main>
        <div style="page-break-after:always;"></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <h2 style="text-align:center; page-break-before:always;">FORM METERAN AIR</h2><h2 style="text-align:center;"><?php echo e($bulan); ?></h2>
        <?php $__currentLoopData = $dataset[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($data[0]); ?></h3>
        <main>
            <table class="tg">
                <thead>
                    <tr>
                        <th class="tg-r8fv">No.</th>
                        <th class="tg-r8fv">Kontrol</th>
                        <th class="tg-r8fv">Pengguna</th>
                        <th class="tg-r8fv">Nomor</th>
                        <th class="tg-r8fv">Lalu</th>
                        <th class="tg-r8fv" style="width:18%">Baru</th>
                        <th class="tg-r8fv" style="width:10%">Ket.</th>
                    </tr>
                </thead>
                <?php $x=1; ?>
                <?php $__currentLoopData = $data[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <td class="tg-cegc"><?php echo e($x); ?></td>
                        <td class="tg-cegc"><?php echo e($d->kontrol); ?></td>
                        <td class="tg-g25h" style="text-align:left;"><?php echo e(substr($d->nama,0,13)); ?></td>
                        <td class="tg-g25h" style="text-align:center;"><?php echo e(($d->nomor)); ?></td>
                        <td class="tg-g25h" style="text-align:right;"><?php echo e(number_format($d->lalu)); ?></td>
                        <td></td>
                        <td><?php echo e($d->lokasi); ?></td>
                    </tr>
                </tbody>
                <?php $x++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </main>
        <div style="page-break-after:always;"></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php endfor; ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/tagihan/print.blade.php ENDPATH**/ ?>