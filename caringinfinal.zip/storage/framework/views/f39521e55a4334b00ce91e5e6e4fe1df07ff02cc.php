<div class="table-responsive">
    <table 
        class="table" 
        id="penghapusan"
        cellspacing="0"
        width="100%"
        style="font-size:0.75rem;">
        <thead class="table-bordered">
            <tr>
                <th>Periode</th>
                <th>Kontrol</th>
                <th>Pengguna</th>
                <th class="listrik">Listrik</th>
                <th class="air">Air Bersih</th>
                <th class="keamanan">Keamanan & IPK</th>
                <th class="kebersihan">Kebersihan</th>
                <th style="background-color:rgba(50, 255, 255, 0.2);">Air Kotor</th>
                <th style="background-color:rgba(255, 50, 255, 0.2);">Lain - Lain</th>
                <th style="background-color:rgba(255, 212, 71, 0.2);">Total</th>
                <th>Via Hapus</th>
            </tr>
        </thead>
    </table>
</div><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/datausaha/penghapusan.blade.php ENDPATH**/ ?>