<div class="table-responsive">
    <table 
        class="table" 
        id="bongkaran"
        cellspacing="0"
        width="100%"
        style="font-size:0.75rem;">
        <thead class="table-bordered">
            <tr>
                <th rowspan="2">Kontrol</th>
                <th colspan="4">Denda</th>
                <th rowspan="2">Tunggakan</th>
                <th rowspan="2">Bongkar</th>
            </tr>
            <tr>
                <th>Ke - 1</th>
                <th>Ke - 2</th>
                <th>Ke - 3</th>
                <th>Ke - 4</th>
            </tr>
        </thead>
    </table>
</div><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\views/datausaha/bongkaran.blade.php ENDPATH**/ ?>