//Show Tagihan
$(document).ready(function () {
    $('#tabelKasir').DataTable({
        processing: true,
		serverSide: true,
		ajax: {
			url: "/kasir",
		},
		columns: [
			{ data: 'kd_kontrol', name: 'kd_kontrol', class : 'text-center' },
			{ data: 'tagihan', name: 'tagihan', class : 'text-center', orderable: false },
			{ data: 'pengguna', name: 'pengguna', class : 'text-center', orderable: false },
			{ data: 'lokasi', name: 'lokasi', class : 'text-center', orderable: false },
			{ data: 'action', name: 'action', class : 'text-center', orderable: false, searchable: false },
        ],
        pageLength: 3,
        stateSave: true,
        scrollX: true,
        deferRender: true,
        dom : "r<'row'<'col-sm-12 col-md-6'><'col-sm-12 col-md-6'f>><'row'<'col-sm-12'tr>><'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        responsive : true,
    });

    var kode_kontrol = '';
    $(document).on('click', '.bayar', function(){
        kontrol = $(this).attr('id');
        $("#divListrik").hide();
        $("#divAirBersih").hide();
        $("#divKeamananIpk").hide();
        $("#divKebersihan").hide();
        $("#divAirKotor").hide();
        $("#divTunggakan").hide();
        $("#divDenda").hide();
        $("#divLain").hide();
		$.ajax({
			url :"/kasir/rincian/" + kontrol,
			dataType:"json",
			success:function(data)
			{
                $("#tempatId").val(kontrol);
                $("#judulRincian").html(kontrol);
                var total = 0;
                if(Number(data.result.listrik) != 0){
                    $("#divListrik").show();
                    $("#nominalListrik").html(Number(data.result.listrik).toLocaleString());
                    total = total + Number(data.result.listrik);
                }
                if(Number(data.result.airbersih) != 0){
                    $("#divAirBersih").show();
                    $("#nominalAirBersih").html(Number(data.result.airbersih).toLocaleString());
                    total = total + Number(data.result.airbersih);
                }
                if(Number(data.result.keamananipk) != 0){
                    $("#divKeamananIpk").show();
                    $("#nominalKeamananIpk").html(Number(data.result.keamananipk).toLocaleString());
                    total = total + Number(data.result.keamananipk);
                }
                if(Number(data.result.kebersihan) != 0){
                    $("#divKebersihan").show();
                    $("#nominalKebersihan").html(Number(data.result.kebersihan).toLocaleString());
                    total = total + Number(data.result.kebersihan);
                }
                if(Number(data.result.airkotor) != 0){
                    $("#divAirKotor").show();
                    $("#nominalAirKotor").html(Number(data.result.airkotor).toLocaleString());
                    total = total + Number(data.result.airkotor);
                }
                if(Number(data.result.tunggakan) != 0){
                    $("#divTunggakan").show();
                    $("#nominalTunggakan").html(Number(data.result.tunggakan).toLocaleString());
                    total = total + Number(data.result.tunggakan);
                }
                if(Number(data.result.denda) != 0){
                    $("#divDenda").show();
                    $("#nominalDenda").html(Number(data.result.denda).toLocaleString());
                    total = total + Number(data.result.denda);
                }
                if(Number(data.result.lain) != 0){
                    $("#divLain").show();
                    $("#nominalLain").html(Number(data.result.lain).toLocaleString());
                    total = total + Number(data.result.lain);
                }
                $('#nominalTotal').html('Rp. ' + total.toLocaleString()); 
                $('#myRincian').modal('show');
			}
        })
        kode_kontrol = kontrol;
    });

    $('#form_rincian').on('submit', function(event){
		event.preventDefault();
		$.ajax({
			url: '/kasir',
			method:"POST",
			data:$(this).serialize(),
			dataType:"json",
			success:function(data)
			{
				var html = '';
				if(data.errors)
				{
                    html = '<div class="alert alert-danger" id="error-alert"> <strong>Oops ! </strong>' + data.errors + '</div>';
				}
				if(data.success)
				{
                    html = '<div class="alert alert-success" id="success-alert"> <strong>Sukses ! </strong>' + data.success + '</div>';
                    ajax_print('/kasir/bayar/' + kode_kontrol);
					$('#tabelKasir').DataTable().ajax.reload();
				}
                $('#myRincian').modal('hide');
                $('#form_result').html(html);
                $("#success-alert,#error-alert,#info-alert,#warning-alert")
                    .fadeTo(2000, 1000)
                    .slideUp(2000, function () {
                        $("#success-alert,#error-alert").slideUp(1000);
                });
			}
		});
    });

    $('#myModal').on('shown.bs.modal', function () {
        $('#kode').trigger('focus');
    });

    $('#kode').on('keypress', function (event) {
        var regex = new RegExp("^[0-9]+$");
        var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
        if (!regex.test(key)) {
        event.preventDefault();
        return false;
        }
    });

    //Print Via Bluetooth atau USB
    function pc_print(data){
        var socket = new WebSocket("ws://127.0.0.1:40213/");
        socket.bufferType = "arraybuffer";
        socket.onerror = function(error) {  
            alert("Transaksi Berhasil Tanpa Print Struk");
        };			
        socket.onopen = function() {
            socket.send(data);
            socket.close(1000, "Work complete");
        };
    }	

    function android_print(data){
        window.location.href = data;  
    }

    function ajax_print(url) {
        $.get(url, function (data) {
            var ua = navigator.userAgent.toLowerCase();
            var isAndroid = ua.indexOf("android") > -1; 
            if(isAndroid) {
                android_print(data);
            }else{
                pc_print(data);
            }
        }).fail(function () {
            alert("Gagal Melakukan Print");
        });
    }
});