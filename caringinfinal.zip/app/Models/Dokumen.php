<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dokumen extends Model
{
    use HasFactory;
    protected $table ='dokumen';
    protected $fillable = [
        'id',
        'kd_kontrol',
        'nama',
        'srt_permohonan',
        'srt_acara',
        'srt_bongkar',
        'updated_at',
        'created_at'
    ];
}
