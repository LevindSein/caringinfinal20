<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

use App\Models\TempatUsaha;
use App\Models\User;
use App\Models\Tagihan;
use App\Models\PasangAlat;

class Kasir extends Model
{
    use HasFactory;

    public static function tagihan(){
        
    }
}
