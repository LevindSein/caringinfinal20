<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DataTables;
use Validator;
use Exception;

use App\Models\Blok;
use App\Models\TempatUsaha;

class BlokController extends Controller
{
    public function __construct()
    {
        $this->middleware('blok');
    }

    public function index(Request $request){
        if($request->ajax())
        {
            $data = Blok::orderBy('nama','asc')->get();
            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function($data){
                    $button = '<a type="button" title="Edit" name="edit" id="'.$data->id.'" class="edit"><i class="fas fa-edit fa-sm" style="color:#4e73df;"></i></a>';
                    $button .= '&nbsp;&nbsp;<a type="button" title="Hapus" name="delete" id="'.$data->id.'" class="delete"><i class="fas fa-trash-alt" style="color:#e74a3b;"></i></a>';
                    return $button;
                })
                ->addColumn('jumlah', function($data){
                    $pengguna = TempatUsaha::where('blok',$data->nama)->count();
                    return $pengguna;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('blok.index');
    }

    public function store(Request $request){

    }

    public function edit($id){

    }

    public function update(Request $request, Blok $blok){

    }

    public function destroy($id){

    }
}
