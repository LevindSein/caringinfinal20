<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

use App\Models\IndoDate;
use App\Models\Dokumen;

class DownloadController extends Controller
{
    public function __construct()
    {
        $this->middleware('human');
    }

    public function download($file){
        if($file == 'bg1'){
            // $test = TestDoc::find(1);
            // header("Content-type: application/msword");
            // header("Content-disposition: attachment; filename=Pemasangan Baru.doc");
        }
    }
}
