<div class="table-responsive">
    <table 
        class="table" 
        id="tunggakan"
        cellspacing="0"
        width="100%"
        style="font-size:0.75rem;">
        <thead class="table-bordered">
            <tr>
                <th>Bulan</th>
                <th class="listrik">Listrik</th>
                <th class="air">Air Bersih</th>
                <th class="keamanan">Keamanan & IPK</th>
                <th class="kebersihan">Kebersihan</th>
                <th style="background-color:rgba(50, 255, 255, 0.2);">Air Kotor</th>
                <th style="background-color:rgba(255, 50, 255, 0.2);">Lain - Lain</th>
                <th style="background-color:rgba(255, 212, 71, 0.2);">Total</th>
            </tr>
        </thead>
    </table>
</div>