@extends('layout.master')
@section('head')
<!-- Tambah Content Pada Head -->
@endsection

@section('content')
<!-- Tambah Content Pada Body Utama -->
<div class = "container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <title>Surat Listrik | BP3C</title>
            <h6 class="m-0 font-weight-bold text-primary">Data Surat Pengajuan Listrik Bulan {{$bulan}}</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive ">
                <table
                    class="table"
                    id="tabelTempat"
                    width="100%"
                    cellspacing="0"
                    style="font-size:0.75rem;">
                    <thead class="table-bordered">
                        <tr>
                            <th>Kontrol</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($dataset as $d)
                        <tr>
                            <td style="text-align:center">{{$d->kd_kontrol}}</td>
                        </tr>
                    </tbody>
                    @endforeach
                </table>
            </div>
        </div>
    </div>    
</div>
@endsection

@section('js')
<!-- Tambah Content pada Body JS -->
@endsection