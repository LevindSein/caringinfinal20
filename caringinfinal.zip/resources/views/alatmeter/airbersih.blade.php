<div class="table-responsive">
    <table 
        class="table table-bordered" 
        id="tabelAlatAir"
        cellspacing="0"
        width="100%"
        style="font-size:0.75rem;">
        <thead>
            <tr>
                <th style="width:10px;">No.</th>
                <th>Kode</th>
                <th>Nomor</th>
                <th>Stand</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
    </table>
</div>