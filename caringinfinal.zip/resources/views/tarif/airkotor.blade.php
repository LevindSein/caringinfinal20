<div class="table-responsive">
    <table 
        class="table" 
        id="tabelAirKotor"
        cellspacing="0"
        width="100%"
        style="font-size:0.75rem;">
        <thead class="table-bordered">
            <tr>
                <th style="width:40px;">Kategori</th>
                <th>Tarif (Rp.)</th>
                <th>Action</th>
            </tr>
        </thead>
    </table>
</div>