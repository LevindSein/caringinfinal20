<?php    
    echo "<script>alert('selesai under construction')</script>";
?>