<?php    
    echo "<script>alert('prabayar under construction')</script>";
?>