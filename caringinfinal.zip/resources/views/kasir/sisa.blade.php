<?php    
    echo "<script>alert('sisa under construction')</script>";
?>