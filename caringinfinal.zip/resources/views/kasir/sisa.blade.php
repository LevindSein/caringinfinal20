<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Sisa Tagihan</title>
        <link rel="stylesheet" href="{{asset('css/penerimaan.css')}}" media="all"/>
        <link rel="icon" href="{{asset('img/logo.png')}}">
    </head>

    <body onload="window.print()">
        <div>
            <header class="clearfix">
                <h2 style="text-align:center;">Rekap Sisa Tagihan<br>{{$bulan}}</h2>
            </header>
            <main>
                <table class="tg">
                    <thead>
                        <tr>
                            <th class="tg-r8fv">No</th>
                            <th class="tg-r8fv">Blok</th>
                            <th class="tg-r8fv">Rekening</th>
                            <th class="tg-r8fv">Listrik</th>
                            <th class="tg-r8fv">Air Bersih</th>
                            <th class="tg-r8fv">Keamanan IPK</th>
                            <th class="tg-r8fv">Kebersihan</th>
                            <th class="tg-r8fv">Air Kotor</th>
                            <th class="tg-r8fv">Lain Lain</th>
                            <th class="tg-r8fv">Jumlah</th>
                        </tr>
                        <tr>
                            <td class="tg-g255" colspan="12" style="height:1px"></td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="tg-r8fz"><b>1</b></td>
                            <td class="tg-r8fz">A-1</td>
                            <td class="tg-r8fy">{{number_format(0)}}</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx"><b>{{number_format(0)}}</b></td>
                        </tr>
                    </tbody>
                    <tr>
                        <td class="tg-g255" colspan="12" style="height:1px"></td>
                    </tr>
                    <tr>
                        <td class="tg-r8fz" colspan="3"><b>Total<b></td>
                        <td class="tg-r8fx"><b>{{number_format(0)}}</b></td>
                        <td class="tg-r8fx"><b>{{number_format(0)}}</b></td>
                        <td class="tg-r8fx"><b>{{number_format(0)}}</b></td>
                        <td class="tg-r8fx"><b>{{number_format(0)}}</b></td>
                        <td class="tg-r8fx"><b>{{number_format(0)}}</b></td>
                        <td class="tg-r8fx"><b>{{number_format(0)}}</b></td>
                        <td class="tg-r8fx"><b>{{number_format(0)}}</b></td>
                    </tr>
                </table>
            </main>
        </div>
        <div style="page-break-before:always">
            <header class="clearfix">
                <h2 style="text-align:center;">Rincian Sisa Tagihan<br>{{$bulan}}</h2>
            </header>
            <main>
                <table class="tg">
                    <thead>
                        <tr>
                            <th class="tg-r8fv">No</th>
                            <th class="tg-r8fv">Kontrol</th>
                            <th class="tg-r8fv">Nama</th>
                            <th class="tg-r8fv" style="width:5%">No.Los</th>
                            <th class="tg-r8fv">Listrik</th>
                            <th class="tg-r8fv">Air Bersih</th>
                            <th class="tg-r8fv">Keamanan IPK</th>
                            <th class="tg-r8fv">Kebersihan</th>
                            <th class="tg-r8fv">Air Kotor</th>
                            <th class="tg-r8fv">Lain Lain</th>
                            <th class="tg-r8fv">Jumlah</th>
                            <th class="tg-r8fv">Keterangan</th>
                        </tr>
                        <tr>
                            <th class="tg-g255" colspan="12" style="height:1px"></th>
                        </tr>
                    </thead>
                    <?php $i = 1; ?>
                    <tbody>
                        <tr>
                            <td class="tg-r8fz"><b>{{$i}}</b></td>
                            <td class="tg-r8fz">A-1-001</td>
                            <td class="tg-r8fy">{{substr('Fahni Amsyari',0,13)}}</td>
                            <td class="tg-r8fz" style="white-space:normal;">1,2,3,4</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx">{{number_format(0)}}</td>
                            <td class="tg-r8fx"><b>{{number_format(0)}}</b></td>
                            <td class="tg-r8fy" style="white-space:normal;">Sesuatu</td>
                        </tr>
                    <?php $i++; ?>
                    </tbody>
                </table>
            </main>
        </div>
    </body>
</html>